<?php $__env->startSection('title'); ?>
Profile Sekolah <?php echo e($profileSekolah->sekolah_nama); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4 class="page-title">Profile</h4>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Profile <?php echo e($profileSekolah->sekolah_nama); ?></div>
            </div>
            <div class="card-body">
                <?php if(session("status")): ?>
                <div class="badge badge-<?php echo e(session("type")); ?>">
                    <?php echo e(session("status")); ?>

                </div>
                <?php endif; ?>
                <ul class="nav nav-pills nav-secondary nav-pills-no-bd" id="pills-tab-without-border" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="pills-home-tab-nobd" data-toggle="pill" href="#profile"
                            role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-profile-tab-nobd" data-toggle="pill" href="#password" role="tab"
                            aria-controls="password" aria-selected="false">Ubah Password</a>
                    </li>
                </ul>
                <div class="tab-content mt-2 mb-3" id="pills-without-border-tabContent">
                    <div class="tab-pane fade show active" id="profile" role="tabpanel"
                        aria-labelledby="pills-home-tab-nobd">
                        <hr>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <td>NPSN</td>
                                        <td>: <?php echo e($profileSekolah->npsn); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nama Sekolah</td>
                                        <td>: <?php echo e($profileSekolah->sekolah_nama); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kepala Sekolah</td>
                                        <td>: <?php echo e($profileSekolah->sekolah_kepsek); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email Sekolah</td>
                                        <td>: <?php echo e($profileSekolah->sekolah_email); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Alamat Sekolah</td>
                                        <td>: Kecamatan <?php echo e($profileSekolah->kec); ?>, Kabupaten<?php echo e($profileSekolah->kab); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Kode Pos</td>
                                        <td>: <?php echo e($profileSekolah->kode_pos); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="pills-profile-tab-nobd">
                        <form action="<?php echo e(route('profile.update',[$profileSekolah->npsn])); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <div class="form-group">
                                <label for="old_password">Password Lama</label>
                                <input class="form-control w-50 <?php $__errorArgs = ["old_password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="password" name="old_password" id="old_password">
                                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="new_password">Password Lama</label>
                                <input class="form-control w-50 <?php $__errorArgs = ["new_password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="password" name="new_password" id="new_password">
                                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Password Lama</label>
                                <input class="form-control w-50 <?php $__errorArgs = ["confirm_password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="password" name="confirm_password" id="confirm_password">
                                <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-secondary btn-rounded" value="Ubah">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ARYA\Customer\simbkk\resources\views/user/update.blade.php ENDPATH**/ ?>