<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Sekolah</th>
                <th>Bekerja</th>
                <th>Melanjutkan</th>
                <th>Wiraswasta</th>
                <th>Belum Terserap</th>
            </tr>
        </thead>
        <tbody>
            <?php $ExportExcelController = app('App\Http\Controllers\ExportExcelController'); ?>
            <?php $__currentLoopData = $sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php
                    $i++;
                    echo $i;
                    ?>
                </td>
                <td>
                    <?php echo e($item->sekolah_nama); ?>

                </td>
                <td align="center">
                    <?php echo e($ExportExcelController::rekapSemua($item->npsn,"1")); ?>

                </td>
                <td align="center">
                    <?php echo e($ExportExcelController::rekapSemua($item->npsn,"2")); ?>

                </td>
                <td align="center">
                    <?php echo e($ExportExcelController::rekapSemua($item->npsn,"3")); ?>

                </td>
                <td align="center">
                    <?php echo e($ExportExcelController::rekapSemua($item->npsn,"4")); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\ARYA\Customer\simbkk\resources\views/rekap/semua.blade.php ENDPATH**/ ?>