<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="<?php echo e(route('test.test')); ?>" method="get">
        <label for="">Masukkan Jumlah Input</label><input type="text" name="kolom" value="<?php echo e($input); ?>">
        <button type="submit">klik</button>
        <br>
        <br>
        <label for="">Jumlah Kolom : <?php echo e($input); ?></label>
        <?php if($input): ?>
        <?php for($i = 1; $i <= $input; $i++): ?> <br><label for="">Mata Pelajaran <?php echo e($i); ?></label>
            <input type='test' name="pelajaran[]">
            <label for="">Jam</label>
            <input type="text" name="jam[]">
            <label for="">Nilai</label>
            <input type="text" name="nilai[]">
            <?php endfor; ?>
            <?php endif; ?>
            <?php if($input): ?>
            <input type="submit" name="kirim" value="kirim">
            <?php endif; ?>
    </form>
</body>

</html>
<?php /**PATH D:\ARYA\Customer\simbkk\resources\views/testinput.blade.php ENDPATH**/ ?>