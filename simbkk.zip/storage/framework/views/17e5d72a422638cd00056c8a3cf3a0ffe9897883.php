<div class="preloader">
    <div class="loading text-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only text-black-50">Loading...</span>
        </div>
        <p class="text-center mt-4">Silahkan Tunggu....</p>
    </div>
</div>
<?php /**PATH D:\ARYA\Customer\simbkk\resources\views/preloader/loadContent.blade.php ENDPATH**/ ?>