<?php $__env->startSection('title'); ?>
Rekap Data
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="<?php echo e(asset('js/rekap.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4 class="page-title">
        Rekap Data
    </h4>
</div>
<div class="row">
    <div class="col-md-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleAdmin')): ?>
        <div class="card">
            <div class="card-header">
                <div class="card-head-row">
                    <h4 class="card-title">Rekap Semua Sekolah</h4>
                    <div class="card-tools">
                        <?php if(session('status_semua_sekolah')): ?>
                        <span class="badge badge-danger"><?php echo e(session('status_semua_sekolah')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <select name="semua" id="semua" class=" form-control w-50" aria-placeholder="Rekap Semua Sekolah"
                        disabled></select>
                </div>
                <a href="<?php echo e(route('export.semua.sekolah')); ?>" class="btn btn-secondary ml-2">Download</a>
            </div>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleAdminOpeartor')): ?>
        <div class="card">
            <div class="card-header">
                <div class="card-head-row">
                    <h4 class="card-title text-capitalize">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleOperatorSekolah')): ?>
                        Rekap <?php echo e(\Auth::user()->sekolahs->sekolah_nama); ?>

                        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleAdmin',)): ?>
                        Rekap Berdasarkan Sekolah
                        <?php endif; ?>
                    </h4>
                    <div class="card-tools">
                        <?php if(session('status_persekolah')): ?>
                        <span class="badge badge-danger"><?php echo e(session('status_persekolah')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('export.per.sekolah')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-group">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleAdmin')): ?>
                        <select name="npsn" id="npsn" class="<?php $__errorArgs = ['npsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            style="width: 50% !important;"></select>
                        <?php $__errorArgs = ['npsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleOperatorSekolah')): ?>
                        <select name="npsn" id="npsn" class=" form-control w-50" disabled></select>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Download</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="card-head-row">
                    <h4 class="card-title">Rekap Berdasarkan Angkatan</h4>
                    <div class="card-tools">
                        <?php if(session('status_angkatan')): ?>
                        <span class="badge badge-danger"><?php echo e(session('status_angkatan')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('export.per.angkatan')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-group">
                        <select name="angkatan" id="angkatan" class="<?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            style="width: 50% !important;"></select>
                        <?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Download</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleAdmin')): ?>
        <div class="card">
            <div class="card-header">
                <div class="card-head-row">
                    <h4 class="card-title">Rekap Berdasarkan Jurusan/Komli</h4>
                    <div class="card-tools">
                        <?php if(session('status_komli')): ?>
                        <span class="badge badge-danger"><?php echo e(session('status_komli')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('export.per.komli')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-group">
                        <select name="komli" id="komli" class="<?php $__errorArgs = ['komli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            style="width: 50% !important;"></select>
                        <?php $__errorArgs = ['komli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-secondary ml-2">Download</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ARYA\Customer\simbkk\resources\views/rekap/index.blade.php ENDPATH**/ ?>