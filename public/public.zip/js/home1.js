var table = $("#data_table_home").DataTable({
    processing: true,
    serverSide: true,
    ajax: "siswa",
    columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            searchable: false
        },
        {
            data: "nisn",
            name: "nisn"
        },
        {
            data: "siswa_nama",
            name: "siswa_nama"
        },
        {
            data: "siswa_sekolah",
            nama: "siswa_sekolah"
        },
        {
            data: "siswa_angkatan",
            name: "siswa_angkatan"
        },
        {
            data: "tempat_lahir",
            nama: "tempat_lahir"
        },
        {
            data: "tanggal_lahir",
            nama: "tanggal_lahir"
        },
        {
            data: "siswa_jk",
            nama: "siswa_jk"
        },
        {
            data: "siswa_komli",
            nama: "siswa_komli"
        },
        {
            data: "siswa_prestasi",
            nama: "siswa_prestasi"
        },
        {
            data: "siswa_keterserapan",
            nama: "siswa_keterserapan"
        },
        {
            data: "keterangan",
            nama: "keterangan"
        }
    ]
});
